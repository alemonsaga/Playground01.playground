Playgroundunlugardondepracticar

import UIKit

Asignacióndevalormutable

varv1="estoesSwift”

Asignación; de valor inmutable

let c1 = 4

Asignaciónformal(definiendoeltipodedato)

var cadena:String = String()

cadena =“Hola mundo”+v1

print("El contenido es: \(cadena)")

print("El valor de constante es: \(c1)")
