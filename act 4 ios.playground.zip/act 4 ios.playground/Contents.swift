import UIKit
//Playground - Actividad 4

//·Condiciones y ciclos
//·Funciones
//·Enumeración

//Condiciones y Ciclos

//A)Declarar la variable "datos" con los valores[3,6,9,2,4,1]

//B)realizar el recorrido de la Variable "datos" con la instrucción "for"

//Condicionales
//vardia=false

//ifdia {print("Es de dia")}else {print("Es de dia")}
var n = 3
//switchn{
//case1:
    print("Es uno")
//case2:
    print("Es dos")
//case3:
   // print("Estres")
//default:
    //print("Mayora3")}

var x = 0

//al menos realiza un ciclo
//repeat{
 //   x++
//}whilex<4



//Si no cumple no ingresa al ciclo
//whilex<6{
 //   x++}
//forvary=x;y<10;y++ {y}

//C)Encontrar los valores menos a 5

//Condicionales
//vardia=false

//ifdia {print("Es de dia"}else {print("Es de dia")}
//varn=3
switch n {
case 1:
    print("Es uno")
case 2:
    print("Es dos")
case 3:
    print("Es tres")
default:
    print("Mayor a 3")
}
//varx=0

//al menos realiza un ciclo
repeat{
//x+
}while x<4



//Si no cumple no ingresa al ciclo
//while x<6 {x++}
//forvary=x;y<10;y++ {y}

//FUNCIONES

//A)Crea la función "suma" qué reciba dos parámetros de tipo entero regresando la suma de ambos números

//Declaración de función

func suma(a:Int, b:Int) -> Int {
    return a + b
}
func saludo(mensaje:String)-> String{
    return "Hola\(mensaje)"
}

suma(a: 3, b: 2)
//saludo("Developer")

//B)Crear la función "potencia" qué reciba dos parámetros de tipo entero, el primer parámetro para el número base y el segundo la potencia a elevar, regresando el resultado de la potencia

//Declaración de función

//funsuma(a:Int, b:Int)->Int{returna+b}
//funcsaludo(mensaje:String)->String{return"Hola\(mensaje)"}

suma(a: 3, b: 2)
//saludo("Developer")



//ENUMERACIONES

//A)Crea la enumeración "meses" para definir tipos de datos basados en los meses del año

//Declaración de enumeración

//enumMeses{
//caseEnero
//caseFebrero
//caseMarzo
//caseAbril
//caseMayo
//caseJunio
//caseJulio
//caseAgosto
//caseSeptiembre
//caseOctubre
//caseNoviembre
//caseDiciembre}

//var queMesEs:Meses
//queMesEs=.Enero


//switchqueDiaEs {case.Sabado:print("Es Sabado")case.Domingo:print("Es Domingo")}

//B)Crear la función "numeroMES" qué reciba el tipo de dato "meses" y regrese el numero del mes correspondiente

//Declaración de enumeración

//enumMeses{case Sabadocase Domingo}

//varqueDiaEs:FinSemana
//queDiaEs=.Domingo


//switchqueDiaEscase.Sabado:
   // print("Es Sabado")
//case.Domingo:
   // print("Es Domingo")}

//C)Para regresar el número de mes correspondiente utilizar la "switch"

//Declaración de enumeración

//enumMeses{
//caseEnero
//caseFebrero
//caseMarzo
//caseAbril
//caseMayo
//caseJunio
//caseJulio
//caseAgosto
//caseSeptiembre
//caseOctubre
//caseNoviembre
//caseDiciembre}

//varqueMesEs:FinSemana
//queMesEs =.Diciembre

//switchqueMesEs{
//case1
//case2
//case3
//case4
//case5
//case6
//case7
//case8
//case9
//case10
//case11
//case12}
   
//case.1:
//print("Es1")
//case.2:
//print("Es 2")
//case.3:
//print("Es3")
//case.4:
//print("Es 4")
//case.5:
//print("Es5")
//case.6:
//print("Es 6")
//case.7:
//print("Es7")
//case.8:
//print("Es 8")
//case.9:
//print("Es9")
//case.10:
//print("Es10")
//case.11:
//print("Es11")
//case12:
//print("Es12")}
