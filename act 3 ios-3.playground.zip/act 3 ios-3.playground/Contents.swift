import UIKit

//Playground - Actividad 3

//·tipos de datos
//·asociacion de tipos
//·arreglos y diccionarios




//Actividaddetiposdedatos

//A) Declarar cuatro variables con tres diferentes tipos de datos, cada uno que corresponda a una numero entero, un numero decimal (flotante), una cadena de texto, realizando la asignación explicita y la asignación inferida

var numero = 3
let otro_numero:Int = 4
var texto = "Hola Swift"
let otro_texto:String = "Programado"
var decimal = 5.1
let otro_decimal:Float = 6.1
var cierto = true
let falso:Bool = false

//otro_numero=5

//Asociacióndetipos

//A)Declara el tipo de dato por asociación para un tipo de dato String
//vardato1:String=String(
//vardato1=3
//vardato3="abd"

//B)Declara el tipo de dato por asociación para un tipo de dato  Número entero.
// Int
//let myInt: Int = 1
//let myInt: = 2

//print(myInt + myInt2)

//Arreglos y Diccionarios

//A)Crea la variable "numeros" de tipo Array con números consecutivos del 1 a 10.

//Array
//varnumeros;Array<Int>=Array<Int>()
//numeros:append(1)
numeros:append(2)
numeros:append(3)
numeros:append(4)
numeros:append(5)
numeros:append(6)
numeros:append(7)
numeros:append(8)
numeros:append(9)
numeros:append(10)


//B)Crealavariable"diasSemana"detipoDictionaryconla relaciónnumero:díaEj.1:"Lunes"

//Dictionary
//var directorio:Dictionary<String,Int> =Dictionary<String>, Int>()
directorio = ["2":martes]
directorio["1"] = lunes
directorio = ["4":jueves]
directorio["3"] = miercoles
directorio = ["5":viernes]
directorio["7"] = domingo
directorio = ["6":sabado]

//Condicionales y Ciclos

//A)Declararlaclass_getClassVariable"datos"conlos valores[3,6,9,2,4,1]

//Tipodedatoentero
vardatos:objc_hook_getClass=datos
3
6
9
2
4
1

//B)realizarelrecorridodelavariable"datos"conlainstrucción "for"

//1playground - noun:aplacewherepeoplecanplay

import UIKit

//forvarindex=0;index<5;++index{
    //CUALQUIER CODIGO QUE QUIERAS EJECUTAR
    print(index)}

//C)Encontrar los valores menores a 5
//Remover el valor de un indice especififo
//varremove(at:5)
//vargreeting="Hello, playground"
